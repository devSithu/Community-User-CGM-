<?php

return [
    'USER_PROFILE_COLUMNS' => [
        'user_number','password', 'user_type', 'user_name', 'gender', 'date_of_birth', 
        'nrc_number', 'graduated_from', 'graduated_major', 'graduated_year', 'region', 'address',
        'phone_number', 'email' , 'connect_person','operator_type','nrc_photo'
    ],
];